@extends('master')
    
        @section('title')
          All Shortcode 
        @endsection



        @section('content')
            <div class="col-md-12  result2 colorr">
                


                        <div class="search">            
                           <div class="row">  
                                                            
                                

                           <div class="col-md-2 btn-gp">
                             <a href="{{route('report.index')}}"><button type="button" class="btn btn-success"> Home <span class="glyphicon glyphicon-home"></span></button></a>
                            </div> 
                           <div class="col-md-2 btn-gp">
                             <a href="{{route('shortcode.create')}}"><button type="button" class="btn btn-success"> Add New <span class="glyphicon glyphicon-upload"></span></button></a>
                            </div> 

                            <div class="col-md-6">
                               <h4 class="first-heading text-center"><b>All Shortcode List</b></h4>
                            </div>

                            <div class="col-md-2 btn-gp">
                               {!! Form::open(['route' => ['shortcode.destroy',500],'method' => 'delete']) !!}
                               {!!Form::hidden('id',500)!!}
                               {!!Form::submit('Delete All',array('class'=>'btn btn-danger','onclick'=>'return myFunction()'))!!}
                               {!! Form::close() !!}
                             
                            </div>

                              

                                                      
                                                
                          </div>
                        </div>   <!-- search -->


                <p class="messsage text-center"> {{ session('message') }} </p>
                      <div class="table-responsive res-table-1">          
                         <table class="table table-hover table-1">
                            <thead>
                                 <tr>
                                  <th style="width:5%"> Serial </th>
                                  <th style="width:8%"> Service Id </th>
                                  <th class="text-right" style="width:9%"> Product Id </th> 
                                  <th class="text-right" style="width:10%"> Shortcode </th>
                                  <th class="text-right" style="width:7%"> Keyword </th>
                                  <th class="text-center" style="width:15%"> Service Name </th>
                                  <th style="width:8%"> Service Type </th>
                                  <th class="text-right" style="width:8%"> Type </th>
                                  <th class="text-center" style="width:8%"> Share </th>
                                  <th style="width:10%"> Company Name </th>
                                 </tr>
                             </thead>
                           </table>
                         </div>    

                       <div class="scroll table-responsive">          
                          <table class="table table-hover ">
                            <tbody>
                               <?php $serial=1; ?> 
                               @foreach($all_data as $data)
                                  <tr>
                                     <td style="width:7%"> {{$serial}} </td>  
                                     <td style="width:4%"> {{$data->service_id}} </td>
                                     <td class="text-left" style="width:6%"> {{$data->product_id}} </td>
                                     <td class="text-right" style="width:12%"> {{$data->shortcode}} </td>
                                     <td class="text-center" style="width:6%"> {{$data->keyword}} </td>
                                     <td  style="width:15%"> {{$data->service_name}} </td>
                                     <td style="width:10%"> {{$data->service_type}} </td>
                                     <td style="width:10%"> {{$data->type}} </td>
                                     <td style="width:10%"> {{$data->share}} </td>
                                     <td style="width:10%"> {{$data->company_name}} </td>
                                   <?php $serial++; ?>  
                                   </tr> 
                               @endforeach 
                              </tbody>
                           </table>

                       </div>
                   
           </div>
                    
                            
                         
                           
           @endsection

              