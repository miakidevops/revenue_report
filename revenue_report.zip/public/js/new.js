function myFunction() {
                   if(!confirm("Are You Sure to delete this"))
                   event.preventDefault();
               }