    
        <?php $__env->startSection('title'); ?>
          SUMMARY
        <?php $__env->stopSection(); ?>



        <?php $__env->startSection('content'); ?>
            <div class="col-md-6 col-md-offset-3 col-sm-6 col-xs-6">
               
             <h2 class="text-center summary"> ROBI VAS REVENUE REPORT SAMMARY </h2>
             <h4 class="text-center month"> last 1 month revenue summary </h4>

              <table class="table table-hover">
                 <thead>
                    <tr>	
	                    <th> Name </th>
	                    <th> Total Revenue </th>
	                    <!-- <th> After Vat </th> -->
	                    <th> Miaki Revenue </th>
                    </tr> 
                 </thead>
                 <tbody>
                 	<tr>
	                   <td> IVR </td>
	                   <td> <?php echo e($ivr_amount['ivr_total_revenue']); ?> </td>
	                   <!-- <td> <?php echo e($ivr_amount['ivr_vat']); ?> </td> -->
	                   <td> <?php echo e($ivr_amount['ivr_miaki_revenue']); ?> </td>
	                </tr>
	                <tr>
	                   <td> SMS </td>
	                   <td> <?php echo e($sms_amount['sms_total_revenue']); ?> </td>
	                   <!-- <td> <?php echo e($sms_amount['sms_vat']); ?> </td> -->
	                   <td> <?php echo e($sms_amount['sms_miaki_revenue']); ?> </td>
	                </tr>
	                <tr>
	                   <td> WAP </td>
	                   <td> <?php echo e($wap_amount['wap_total_revenue']); ?> </td>
	                   <!-- <td> <?php echo e($wap_amount['wap_vat']); ?> </td> -->
	                   <td> <?php echo e($wap_amount['wap_miaki_revenue']); ?> </td>
	                </tr> 
                 </tbody>
                 <?php
                 $total_revenue=$ivr_amount['ivr_total_revenue']+$sms_amount['sms_total_revenue']+$wap_amount['wap_total_revenue'];
                 $total_revenue= number_format($total_revenue, 2, '.', ',');

                 $miaki_revenue=$ivr_amount['ivr_miaki_revenue']+$sms_amount['sms_miaki_revenue']+$wap_amount['wap_miaki_revenue'];
                 $miaki_revenue= number_format($miaki_revenue, 2, '.', ',');
                 ?>
                
                   <tfoor>
                    <tr>	
	                    <th> total </th>
	                    <th> <?php echo e($total_revenue); ?> </th>
	                  
	                   <th> <?php echo e($miaki_revenue); ?> </th>
                    </tr> 
                 </tfoor>

              </table>
               
                 <div class="row">
                 	<div class="col-md-4 col-md-offset-4 text-center">
                       <a href="<?php echo e(route('report.index')); ?>"><button type="button" class="btn btn-success nav-button right-bar"> go to detail </button></a>
                     </div>
                  </div>     
            </div>
                            
           <?php $__env->stopSection(); ?>

             



             
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>