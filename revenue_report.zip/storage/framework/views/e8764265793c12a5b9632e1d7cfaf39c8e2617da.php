<html>
     <head>
          <title>  <?php echo $__env->yieldContent('title'); ?> </title>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1">
          <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
         
          <link rel="stylesheet" type="text/css" href="<?php echo e(URL::to('css/first.css')); ?>">
          <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
          <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
     </head>


     <body>


          <div class="container">
              <div class="row">

                <?php echo $__env->yieldContent('content'); ?>

              </div>
          </div>



              	            
              	            
         <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
         <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
         <script src="js/new.js"> </script>
       </body>

 </html>