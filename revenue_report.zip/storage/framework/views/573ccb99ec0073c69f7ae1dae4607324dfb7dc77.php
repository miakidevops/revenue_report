  
      
          <?php $__env->startSection('title'); ?>
            upload short code
          <?php $__env->stopSection(); ?>



          <?php $__env->startSection('content'); ?>
                	  <div class="col-md-6 col-md-offset-3">
                   
               <h4 class="first-heading text-center"><b>Welcome to Upload Shortcode: </b></h4>


				  <?php if($errors->any()): ?>
				      <div class="alert alert-danger">
				          <ul>
				              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				                  <li><?php echo e($error); ?></li>
				              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				          </ul>
				      </div>
				  <?php endif; ?> 

                  <p class="messsage text-center"> <?php echo e(session('message')); ?> </p>
				 
				    <?php echo Form::open(array('route'=>'shortcode.store','files' => true)); ?>

				                   <div class="w3-card login-card"> 

				                     <div class="form-group row">
				                              <div class="col-md-12 col-sm-12 col-xs-12">
				                                   <label class="control-label" for="excell">Upload Excel File(short code): </label>
				                               </div>
				                               <div class="col-md-12 col-sm-12 col-xs-12">
				                                    <input type="file" class="form-control" name="excell" id="excell"> 
				                               </div>
				                     </div>
				                           

				                         <!--  ,'onclick'=>'return myFunction1()' -->
				                           <?php echo Form::submit('submit',array('class'=>'btn btn-success')); ?>


				                           <a href="<?php echo e(route('shortcode.index')); ?>"><button type="button" class="btn btn-success"><span class="glyphicon glyphicon-chevron-left"></span> Back </button></a>
				                     </div>
				    <?php echo Form::close(); ?>  

				

				    				  <p class="note"> download sample file </p>
				                  
				                     <a href=" <?php echo e(URL::to( '/sample/type-2/base.xlsx')); ?>" download="base.xlsx">
				                        <button type="button" class="btn btn-primary edit">
				                           <i class="glyphicon glyphicon-download">
				                             
				                           </i><span> download </span>
				                        </button>
				                     </a>
				
                </div>
		 <?php $__env->stopSection(); ?>		 


<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>