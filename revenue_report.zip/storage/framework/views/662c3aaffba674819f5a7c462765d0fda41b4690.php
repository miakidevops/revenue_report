    
        <?php $__env->startSection('title'); ?>
          All Shortcode 
        <?php $__env->stopSection(); ?>



        <?php $__env->startSection('content'); ?>
            <div class="col-md-12  result2 colorr">
                


                        <div class="search">            
                           <div class="row">  
                                                            
                                

                           <div class="col-md-2 btn-gp">
                             <a href="<?php echo e(route('report.index')); ?>"><button type="button" class="btn btn-success"> Home <span class="glyphicon glyphicon-home"></span></button></a>
                            </div> 
                           <div class="col-md-2 btn-gp">
                             <a href="<?php echo e(route('shortcode.create')); ?>"><button type="button" class="btn btn-success"> Add New <span class="glyphicon glyphicon-upload"></span></button></a>
                            </div> 

                            <div class="col-md-6">
                               <h4 class="first-heading text-center"><b>All Shortcode List</b></h4>
                            </div>

                            <div class="col-md-2 btn-gp">
                               <?php echo Form::open(['route' => ['shortcode.destroy',500],'method' => 'delete']); ?>

                               <?php echo Form::hidden('id',500); ?>

                               <?php echo Form::submit('Delete All',array('class'=>'btn btn-danger','onclick'=>'return myFunction()')); ?>

                               <?php echo Form::close(); ?>

                             
                            </div>

                              

                                                      
                                                
                          </div>
                        </div>   <!-- search -->


                <p class="messsage text-center"> <?php echo e(session('message')); ?> </p>
                      <div class="table-responsive res-table-1">          
                         <table class="table table-hover table-1">
                            <thead>
                                 <tr>
                                  <th style="width:5%"> Serial </th>
                                  <th style="width:8%"> Service Id </th>
                                  <th class="text-right" style="width:9%"> Product Id </th> 
                                  <th class="text-right" style="width:10%"> Shortcode </th>
                                  <th class="text-right" style="width:7%"> Keyword </th>
                                  <th class="text-center" style="width:15%"> Service Name </th>
                                  <th style="width:8%"> Service Type </th>
                                  <th class="text-right" style="width:8%"> Type </th>
                                  <th class="text-center" style="width:8%"> Share </th>
                                  <th style="width:10%"> Company Name </th>
                                 </tr>
                             </thead>
                           </table>
                         </div>    

                       <div class="scroll table-responsive">          
                          <table class="table table-hover ">
                            <tbody>
                               <?php $serial=1; ?> 
                               <?php $__currentLoopData = $all_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <tr>
                                     <td style="width:7%"> <?php echo e($serial); ?> </td>  
                                     <td style="width:4%"> <?php echo e($data->service_id); ?> </td>
                                     <td class="text-left" style="width:6%"> <?php echo e($data->product_id); ?> </td>
                                     <td class="text-right" style="width:12%"> <?php echo e($data->shortcode); ?> </td>
                                     <td class="text-center" style="width:6%"> <?php echo e($data->keyword); ?> </td>
                                     <td  style="width:15%"> <?php echo e($data->service_name); ?> </td>
                                     <td style="width:10%"> <?php echo e($data->service_type); ?> </td>
                                     <td style="width:10%"> <?php echo e($data->type); ?> </td>
                                     <td style="width:10%"> <?php echo e($data->share); ?> </td>
                                     <td style="width:10%"> <?php echo e($data->company_name); ?> </td>
                                   <?php $serial++; ?>  
                                   </tr> 
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                              </tbody>
                           </table>

                       </div>
                   
           </div>
                    
                            
                         
                           
           <?php $__env->stopSection(); ?>

              
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>