<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Content;
use App\Shortcode;
class HomeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
       $ivr_amount['ivr_miaki_revenue']=0;
       $ivr_amount['ivr_total_revenue']=0;
       $ivr_amount['ivr_vat']=0;

       $sms_amount['sms_miaki_revenue']=0;
       $sms_amount['sms_total_revenue']=0;
       $sms_amount['sms_vat']=0;

       $wap_amount['wap_miaki_revenue']=0;
       $wap_amount['wap_total_revenue']=0;
       $wap_amount['wap_vat']=0;


       $start_day=strtotime("today");
       $start_day= date("Y-m-d", $start_day);

       $end_day=strtotime("-30 days");
       $end_day= date("Y-m-d", $end_day);


               $all_data=Content::where('service_type','LIKE','IVR')->
                                  where('time','>=',$end_day)->
                                  where('time','<=',$start_day)->get();

              foreach($all_data as $result){   
                $ivr_amount['ivr_miaki_revenue']+=$result['miaki_revenue'];
                $ivr_amount['ivr_total_revenue']+=$result['total_revenue'];
                $ivr_amount['ivr_vat']+=$result['vat'];
              }    


               $all_data2=Content::where('service_type','LIKE','SMS')->
                                  where('time','>=',$end_day)->
                                  where('time','<=',$start_day)->get();

              foreach($all_data2 as $result){   
                $sms_amount['sms_miaki_revenue']+=$result['miaki_revenue'];
                $sms_amount['sms_total_revenue']+=$result['total_revenue'];
                $sms_amount['sms_vat']+=$result['vat'];
              } 


               $all_data3=Content::where('service_type','LIKE','WAP')->
                                  where('time','>=',$end_day)->
                                  where('time','<=',$start_day)->get();

              foreach($all_data3 as $result){   
                $wap_amount['wap_miaki_revenue']+=$result['miaki_revenue'];
                $wap_amount['wap_total_revenue']+=$result['total_revenue'];
                $wap_amount['wap_vat']+=$result['vat'];
              }           
            
            return view('summary',compact('ivr_amount','sms_amount','wap_amount'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
